// All tunables for the digest widget. Nothing in here should require touching
// render.js/actions.js/digestLoader.js when the org's directory or module names change.

// Org variable (Zoho CRM Settings > Org Variables) holding a JSON map of every user's latest
// digest — {"<userId>": {"url","run_date","profile"}, ...}. Replaces the old single-user
// `Digest_url` string variable now that the widget serves more than one person; the nightly
// Deluge job (deluge/generate/digest_generate.dg) rewrites this variable once per run after looping
// over every active user.
export const DIGEST_REGISTRY_VARIABLE = "Digest_registry";

// Cosmetic header labels per CRM Profile. Falls back to the raw profile name for any profile
// not listed here (including future stub profiles) — no code change needed to onboard one.
export const PROFILE_LABELS = {
  "Sales Manager": "Pilote — Sales Manager",
  "004-SALES": "Mon pipeline",
};

// Deluge Standalone functions the widget calls for the Sales-Manager-only actions (owner
// changes, bulk decisions — see deluge/actions/ for the implementations and
// ../../CLAUDE.md for why these three stay server-side while the rest of actions.js writes
// directly via ZOHO.CRM.API in crmApi.js). sendMentionEmails is the exception that isn't
// profile-gated — it's the compensation-email-only step every plain note post still needs,
// since sending mail has no client-SDK equivalent.
export const ACTION_FUNCTIONS = {
  dispatchInitial: "digest_dispatch_initial",
  redispatchB2bLost: "digest_redispatch_b2b_lost",
  applySupervisionBatch: "digest_apply_supervision_batch",
  sendMentionEmails: "digest_send_mention_emails",
};

// A2 — exact team directory with ids/emails, as verified via getUsers on 26/08.
// Kept as data (not re-derived at runtime) since the nightly Deluge job already re-verifies
// via getUsers before dispatch — this copy is only for widget-side display/tag menus.
export const TEAM = {
  ae: [
    { name: "Jordan Dubois", email: "jordan.d@docshipper.com", id: "4664241000329095001", dispatchTarget: true },
    { name: "Yanis Huin", email: "yanis.h@docshipper.com", id: "4664241000307521001", dispatchTarget: true },
    { name: "Axel Rocheteau", email: "axel.r@docshipper.com", id: "4664241000292115001", dispatchTarget: true },
    { name: "Mehdi EL HAMZAOUI", email: "mehdi.e@docshipper.com", id: "4664241000340111001", dispatchTarget: true },
    { name: "Maxime MORLON", email: "maxime.m@docshipper.com", id: "4664241000250356001", dispatchTarget: false },
    { name: "Constance Dittrich", email: "constance.d@docshipper.com", id: "4664241000082537008", dispatchTarget: false },
  ],
  op: [
    { name: "Mustapha ERRAIS", email: "mustapha.e@docshipper.com", id: "4664241000184211001" },
    { name: "Karim Messaoudi", email: "karim.m@docshipper.com", id: "4664241000090120001" },
    { name: "Joshua SINAMBAN", email: "joshua.s@docshipper.com", id: "4664241000304700001" },
    { name: "Ranya Yâakoubi", email: "ranya.y@docshipper.com", id: "4664241000028329015" },
    { name: "Khalil Kaddour", email: "khalil.k@docshipper.com", id: "4664241000047237083" },
    { name: "Thomas P", email: "thomas.p@docshipper.com", id: "4664241000276434001" },
    { name: "Jewel Hou", email: "jewel.h@docshipper.com", id: "4664241000269742001" },
    { name: "Idriss Ben Chagra", email: "idriss.b@docshipper.com", id: "4664241000148804001", role: "Operations Manager" },
    { name: "Mayne ZHOU", email: "mayne.z@docshipper.com", id: "4664241000352438001", role: "Sales Shipping / Sourcing-Operation" },
    { name: "Sarah Allalout", email: "sarah.a@docshipper.com", id: "4664241000005529026", role: "Sourcing Operation Manager" },
  ],
  managers: [
    { name: "Taher Kharrat", email: "taher.k@docshipper.com", id: "4664241000112085278", role: "Customer Service Manager" },
  ],
  cs: [
    // CS simples — taggable, but never trigger the A7 compensation email.
    { name: "Alba M.", email: "alba.m@docshipper.com" },
    { name: "Eddie s", email: "eddie.s@docshipper.com" },
    { name: "Stéphane H.", email: "stephane.h@docshipper.com" },
    { name: "Sarah RABAA", email: "sarah.r@docshipper.com" },
  ],
};

// Tag-select menu (A5): the 4 dispatch-target AE + Maxime + all OP + managers.
export function tagMenuEntries() {
  return [
    ...TEAM.ae.filter((p) => p.dispatchTarget || p.name === "Maxime MORLON"),
    ...TEAM.op,
    ...TEAM.managers,
  ];
}

// Emails that never trigger the A7 compensation email (Important#5 exception).
const CS_EMAILS = new Set(TEAM.cs.map((p) => p.email));
export function requiresCompensationEmail(taggedEmail) {
  return !CS_EMAILS.has(taggedEmail);
}

// Section order is now data-driven — each digest JSON's own `sections` array (see
// app/js/render.js's SECTION_RENDERERS) determines what renders and in what order, so there's
// no static list to keep in sync here.

// CRM deal record URL builder (used for "Open Deal" links and dslink cells).
export function dealUrl(crmDomain, dealId) {
  return `https://${crmDomain}/crm/tab/Deals/${dealId}`;
}
